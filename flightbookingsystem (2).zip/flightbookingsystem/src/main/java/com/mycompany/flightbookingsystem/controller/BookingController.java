package com.mycompany.flightbookingsystem.controller;

import com.mycompany.flightbookingsystem.model.BookingEntity;
import com.mycompany.flightbookingsystem.service.BookingRequest;
import com.mycompany.flightbookingsystem.service.BookingServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

	@Autowired
	private BookingServices bookingService;

	@PostMapping
	public ResponseEntity<BookingEntity> createBooking(@RequestBody BookingRequest bookingRequest) {
		return ResponseEntity.status(HttpStatus.CREATED).body(bookingService.createBooking(bookingRequest));
	}

	@GetMapping("/{id}")
	public ResponseEntity<BookingEntity> getBooking(@PathVariable Long id) {
		return ResponseEntity.ok(bookingService.getBookingById(id));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> cancelBooking(@PathVariable Long id) {
		bookingService.cancelBooking(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping
	public List<BookingEntity> getAllBookings() {
		return bookingService.getAllBookings();
	}
	

}
