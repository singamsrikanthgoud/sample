package com.mycompany.flightbookingsystem.controller;

import com.mycompany.flightbookingsystem.model.FlightEntity;
import com.mycompany.flightbookingsystem.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/flights")
public class FlightController {
	@Autowired
	private FlightService flightService;

	@PostMapping
	public ResponseEntity<FlightEntity> createFlight(@RequestBody FlightEntity flight) {
		return ResponseEntity.status(HttpStatus.CREATED).body(flightService.createFlight(flight));
	}

	@GetMapping("/{id}")
	public ResponseEntity<FlightEntity> getFlight(@PathVariable Long id) {
		return ResponseEntity.ok(flightService.getFlightById(id));
	}
 
	@PutMapping("/{id}")
	public ResponseEntity<FlightEntity> updateFlight(@PathVariable Long id, @RequestBody FlightEntity flightDetails) {
		return ResponseEntity.ok(flightService.updateFlight(id, flightDetails));
	}
 
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteFlight(@PathVariable Long id) {
		flightService.deleteFlight(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping
	public List<FlightEntity> getAllFlights() {
		return flightService.getAllFlights();
	}

}
