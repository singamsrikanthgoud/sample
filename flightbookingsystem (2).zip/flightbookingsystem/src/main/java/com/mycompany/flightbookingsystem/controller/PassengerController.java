package com.mycompany.flightbookingsystem.controller;

import com.mycompany.flightbookingsystem.model.PassengerEntity;
import com.mycompany.flightbookingsystem.service.PassengerServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/passengers")
public class PassengerController {
	@Autowired
	private PassengerServices passengerServices;

	@PostMapping
	public ResponseEntity<PassengerEntity> createPassenger(@RequestBody PassengerEntity passenger) {
		return ResponseEntity.status(HttpStatus.CREATED).body(passengerServices.createPassenger(passenger));
	}

	@GetMapping("/{id}")
	public ResponseEntity<PassengerEntity> getPassenger(@PathVariable Long id) {
		return ResponseEntity.ok(passengerServices.getPassengerById(id));
	}

	@PutMapping("/{id}")
	public ResponseEntity<PassengerEntity> updatePassenger(@PathVariable Long id,
			@RequestBody PassengerEntity passengerDetails) {
		return ResponseEntity.ok(passengerServices.updatePassenger(id, passengerDetails));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePassenger(@PathVariable Long id) {
		passengerServices.deletePassenger(id);
		return ResponseEntity.noContent().build();
	}
	@GetMapping
	public List<PassengerEntity> getAllPassengers() {
		return passengerServices.getAllPassengers();
	}
}