package com.mycompany.flightbookingsystem.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "bookings")
public class BookingEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Long id;

	@Column
	private LocalDate bookingDate;

	@Column
	private BigDecimal totalAmount;

	@ManyToOne
	@JoinColumn(referencedColumnName = "id")
	private FlightEntity flight;
	@ManyToOne
	@JoinColumn(referencedColumnName = "id")
	private PassengerEntity passengerId;

	@Enumerated(EnumType.STRING)
	@Column
	private Status status;

	public enum Status {
		Confirmed, Cancelled
	}

	;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public FlightEntity getFlight() {
		return flight;
	}

	public void setFlight(FlightEntity flight) {
		this.flight = flight;
	}

	public PassengerEntity getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(PassengerEntity passengerId) {
		this.passengerId = passengerId;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

}
