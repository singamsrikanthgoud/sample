package com.mycompany.flightbookingsystem.repository;

import com.mycompany.flightbookingsystem.model.BookingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<BookingEntity, Long> {

}
