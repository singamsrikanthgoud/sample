package com.mycompany.flightbookingsystem.repository;

import com.mycompany.flightbookingsystem.model.FlightEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FlightRepository extends JpaRepository<FlightEntity, Long> {
}
