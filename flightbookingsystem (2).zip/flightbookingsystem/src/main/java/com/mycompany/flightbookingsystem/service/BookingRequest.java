package com.mycompany.flightbookingsystem.service;

public class BookingRequest {
	private Long flightId;
	private Long passengerId;

	public Long getFlightId() {
		return flightId;
	}

	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}

	public Long getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(Long passengerId) {
		this.passengerId = passengerId;
	}
}
