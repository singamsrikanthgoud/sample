package com.mycompany.flightbookingsystem.service;

import com.mycompany.flightbookingsystem.model.BookingEntity;
import com.mycompany.flightbookingsystem.model.FlightEntity;
import com.mycompany.flightbookingsystem.model.PassengerEntity;
import com.mycompany.flightbookingsystem.repository.BookingRepository;
import com.mycompany.flightbookingsystem.repository.FlightRepository;
import com.mycompany.flightbookingsystem.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class BookingServices {
	@Autowired
	public BookingRepository bookingRepository;
	@Autowired
	private FlightRepository flightRepository;
	@Autowired
	private PassengerRepository passengerRepository;

	public BookingEntity createBooking(BookingRequest bookingRequest) {
		FlightEntity flight = flightRepository.findById(bookingRequest.getFlightId())
				.orElseThrow(() -> new RuntimeException("Flight not found with id " + bookingRequest.getFlightId()));
		if (flight.getSeatsAvailable() <= 0) {
			throw new RuntimeException("No seats available on the flight!");
		}
		PassengerEntity passenger = passengerRepository.findById(bookingRequest.getPassengerId())
				.orElseThrow(() -> new RuntimeException("Passenger not found" + bookingRequest.getPassengerId()));
		BookingEntity booking = new BookingEntity();
		booking.setBookingDate(LocalDate.now());
		booking.setFlight(flight);
		booking.setPassengerId(passenger);
		booking.setTotalAmount(flight.getPricePerSeat());
		booking.setStatus(BookingEntity.Status.Confirmed);

		flight.setSeatsAvailable(flight.getSeatsAvailable() - 1);
		flightRepository.save(flight);

		return bookingRepository.save(booking);
	}

	public BookingEntity getBookingById(Long id) {
		return bookingRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Booking not found with id " + id));
	}

	public void cancelBooking(Long id) {
		BookingEntity booking = getBookingById(id);
		FlightEntity flight = booking.getFlight();
		flight.setSeatsAvailable(flight.getSeatsAvailable() + 1);
		flightRepository.save(flight);
		booking.setStatus(BookingEntity.Status.Cancelled);
		bookingRepository.save(booking);
	}

	public List<BookingEntity> getAllBookings() {
		return bookingRepository.findAll();
	}

}
