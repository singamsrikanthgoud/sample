package com.mycompany.flightbookingsystem.service;

import com.mycompany.flightbookingsystem.model.FlightEntity;
import com.mycompany.flightbookingsystem.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlightService {

	@Autowired
	private FlightRepository flightRepository;

	public FlightEntity createFlight(FlightEntity flight) {
		return flightRepository.save(flight);
	}

	public FlightEntity getFlightById(Long id) {
		return flightRepository.findById(id).orElseThrow(() -> new RuntimeException("Flight not Found with id" + id));
	}

	public FlightEntity updateFlight(Long id, FlightEntity flightDetails) {
		FlightEntity flight = getFlightById(id);
		flight.setFlightNumber(flightDetails.getFlightNumber());
		flight.setDepartureCity(flightDetails.getDepartureCity());
		flight.setArrivalCity(flightDetails.getArrivalCity());
		flight.setDepartureTime(flightDetails.getDepartureTime());
		flight.setSeatsAvailable(flightDetails.getSeatsAvailable());
		flight.setPricePerSeat(flightDetails.getPricePerSeat());
		return flightRepository.save(flight);
	}

	public void deleteFlight(Long id) {
		flightRepository.deleteById(id);
	}

	public List<FlightEntity> getAllFlights() {
		return flightRepository.findAll();
	}

}
