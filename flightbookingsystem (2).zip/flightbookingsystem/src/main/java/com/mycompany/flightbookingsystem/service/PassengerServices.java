package com.mycompany.flightbookingsystem.service;

import com.mycompany.flightbookingsystem.model.PassengerEntity;
import com.mycompany.flightbookingsystem.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PassengerServices {
	@Autowired
	private PassengerRepository passengerRepository;

	public PassengerEntity createPassenger(PassengerEntity passenger) {
		return passengerRepository.save(passenger);
	}

	public PassengerEntity getPassengerById(Long id) {
		return passengerRepository.findById(id).orElseThrow(() -> new RuntimeException("Passenger not found by Id"));
	}

	public PassengerEntity updatePassenger(Long id, PassengerEntity passengerDetails) {
		PassengerEntity passenger = getPassengerById(id);
		passenger.setFirstName(passengerDetails.getFirstName());
		passenger.setLastName(passengerDetails.getLastName());
		passenger.setEmail(passengerDetails.getEmail());
		passenger.setPassportNumber(passengerDetails.getPassportNumber());
		return passengerRepository.save(passenger);
	}

	public void deletePassenger(Long id) {
		passengerRepository.deleteById(id);
	}
	public List<PassengerEntity> getAllPassengers() {
		return passengerRepository.findAll();
	}
}
